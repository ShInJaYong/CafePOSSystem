package control;

import java.util.ArrayList;

public class CoffeeController {
	private ArrayList list = new ArrayList();

	public ArrayList getList() {
		return list;
	}

	public void setList(ArrayList list) {
		this.list = list;
	}
}
