import java.awt.Color;

import javax.swing.JButton;

public class TempButton extends JButton{
	public TempButton(){
		this.setBackground(Color.blue);
	}
	
	public TempButton(String temp){
		super(temp);
		this.setBackground(Color.blue);
	}
}
